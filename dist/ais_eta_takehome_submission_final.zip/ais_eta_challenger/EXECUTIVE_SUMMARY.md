# Executive summary — Company Reference-ETA Benchmark

## Task

The company clarified that, for the exercise, **the ETA contained in `Tracks` should be used as the reference/ground-truth value**. The primary task is therefore to predict that latest reference ETA from the current vessel state and causal historical information in `Positions`.

The project uses one supervised example per MMSI. `Tracks.eta` is target-only; historical features use only `Positions.recorded_at <= Tracks.last_update`.

## Dataset and validation

There are **439 parseable ship ETA references across 439 MMSIs**. The deterministic target-free split is **321 train / 65 calibration / 53 final test**. Candidate models were selected on calibration only, then the final test was opened once.

## Final strict benchmark

Calibration selected **CatBoost on the current/latest Tracks snapshot**.

| Metric | Final test |
|---|---:|
| Rows | 53 |
| MAE | **312.0 h** |
| Median absolute error | **25.3 h** |
| P90 absolute error | 560.4 h |
| Within ±24 h | 43.4% |
| Within ±48 h | 60.4% |

The large mean/median gap is a property of the supplied reference distribution, not hidden by post-hoc filtering.

## Why the mean is so large

M11 keeps all strict labels and explains the heavy tail:

- 64/439 reference ETAs are already in the past at snapshot time;
- 56/439 are more than 7 days in the future;
- the top 5 final-test errors explain **79.1%** of total absolute error;
- the same frozen model has **28.6 h MAE** on the 40 final references 0–7 days in the future.

That 0–7 day number is diagnostic only; the official strict result remains 312.0 h MAE.

## What the frozen model learned

M12 reproduces all 53 final predictions from the frozen CatBoost artifact and uses native importance/SHAP only for explanation. `destination_norm` is the strongest single feature; voyage state, current motion and current location dominate the grouped attribution.

A CatBoost with additional causal history had already been tested before final opening and did **not** improve calibration. For the future-reference diagnostic, a simple train-only destination median was the calibration winner. The evidence therefore does not support “more history / more ML is automatically better” for this particular latest-state reference target.

## Secondary domain work

Before the final target clarification, M0–M9 studied a different question: **physical port-entry ETA** reconstructed from AIS for Catania and Augusta. That branch remains frozen as additional maritime-domain work. It includes provider/data-quality forensics, port-call reconstruction, train-only historical routing, leakage-resistant validation, uncertainty and stability analysis.

It is not used to overwrite or reinterpret the company-defined M10 benchmark.

## Bottom line

The submission provides:

- an exact implementation of the company-defined `Tracks.eta` benchmark;
- a frozen train/calibration/final evaluation protocol;
- explicit diagnosis of reference-label quality rather than silent filtering;
- model explainability without post-final tuning;
- a separate domain-aware physical-arrival investigation showing what changes when the target itself changes;
- an M14 deterministic final submission freeze with per-file SHA-256 integrity verification and clean-room package tests.

No claim is made that the submission beats the externally developed ETA model because its information set and evaluation protocol were not supplied.
Historical **reported AIS ETA** updates are not available in `Positions`; the exercise therefore predicts the latest `Tracks.eta` reference rather than evaluating a longitudinal reported-ETA series.


## Final reproducibility status

M14 is packaging/integrity only. It re-verifies the frozen M10/M6 hashes, builds the final archive deterministically, and validates the extracted package with its content-manifest verifier, analytical tests and static compilation. No model, split or final prediction is changed.
