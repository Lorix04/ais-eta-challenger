# AIS ETA Challenger — Eastern Sicily

Company-facing take-home for the ETA exercise built from the supplied AIS `Positions` and `Tracks` datasets.

## What this submission answers

After clarification from the company, the **primary exercise** is defined as predicting the ETA stored in `Tracks` and using that value as the exercise reference/ground truth.

The project therefore treats:

- `Tracks.eta` as **`reference_eta`** and **target only**;
- `Tracks.last_update` as the prediction-time anchor;
- `Positions` as historical observations used only when `recorded_at <= Tracks.last_update`;
- one MMSI / Tracks record as one supervised example.

`Tracks.eta` is not relabelled as observed Actual Time of Arrival (ATA): the company asked to use it as the exercise reference, and the benchmark follows that instruction exactly.

## Primary result — company reference-ETA benchmark

The reference dataset contains **439 parseable ship ETA references across 439 MMSIs**. A deterministic target-free MMSI split was frozen before the final evaluation:

| Split | Rows |
|---|---:|
| Train | 321 |
| Calibration | 65 |
| Final test | 53 |

Calibration selected **CatBoost using the current/latest Tracks snapshot** for the strict all-parseable benchmark.

| Final-test metric | Result |
|---|---:|
| MAE | **312.0 h** |
| Median absolute error | **25.3 h** |
| P90 absolute error | 560.4 h |
| Within ±24 h | 43.4% |
| Within ±48 h | 60.4% |

The mean is deliberately not "cleaned" after the fact. M11 shows that the error distribution is extremely tail-dominated: the largest 5 final errors explain **79.1%** of total absolute error.

For context only, the **same frozen strict model** has **28.6 h MAE** and **18.1 h median absolute error** on the 40 final references that lie 0–7 days in the future. This is a post-hoc diagnostic, not a replacement benchmark.

## What the model is using

M12 explains the exact frozen CatBoost artifact without refitting it. The strongest single feature is `destination_norm`; current location, SOG/COG/heading and navigation state are also important. The dominant feature groups are voyage state, current motion and current location.

A history-heavy CatBoost was tested **before** the final test and did not improve calibration over the current-snapshot CatBoost. On the future-reference diagnostic, a simple train-only destination median was actually the calibration winner. The project therefore does not claim that a larger model or longer AIS history automatically improves this particular latest-state reference target.

## Reference-label quality findings

The strict benchmark keeps every parseable company reference ETA. Diagnostics show:

- **64/439 (14.6%)** are already in the past at `Tracks.last_update`;
- **56/439** are more than 7 days in the future;
- **86.1%** of ETA minute values are exactly `:00`;
- Message-5 ETA has no year, so year assignment is deterministic but a small number of rows are calendar-sensitive;
- the frozen final predictions span roughly `-109.5 h` to `+93.8 h`, while strict references span roughly `-3055 h` to `+3553 h`.

These properties are reported rather than filtered away.

## Secondary domain-research branch

M0–M9 are preserved as **secondary maritime-domain research**, not as the primary company benchmark. That branch reconstructed physical port-entry events for Catania/Augusta, audited port calls, tested train-only route retrieval, rejected residual ML when it worsened validation, and evaluated uncertainty/stability.

Its final locked physical-arrival holdout produced **36.5 min MAE** for route-kNN physics versus **37.7 min** for geodesic physics; the paired bootstrap interval for the gain included zero. This branch is useful to show how the problem changes when the target is physical arrival rather than the latest reported/reference ETA.

## Recommended reading order

1. [`EXECUTIVE_SUMMARY.md`](EXECUTIVE_SUMMARY.md) — two-minute summary.
2. [`TAKE_HOME_REPORT.md`](TAKE_HOME_REPORT.md) — full company-facing technical narrative.
3. [`reports/M10_REPORT.md`](reports/M10_REPORT.md) — frozen primary benchmark.
4. [`reports/M11_REPORT.md`](reports/M11_REPORT.md) — reference-label/error forensics.
5. [`reports/M12_REPORT.md`](reports/M12_REPORT.md) — frozen-model explainability and ablation.
6. [`docs/MODEL_CARD.md`](docs/MODEL_CARD.md) — intended use, evaluation and limitations.
7. [`reports/M14_REPRODUCIBILITY_REPORT.md`](reports/M14_REPRODUCIBILITY_REPORT.md) — final reproducibility/submission freeze.
8. [`docs/REPRODUCIBILITY.md`](docs/REPRODUCIBILITY.md) — replay and test instructions.

## Final submission freeze

M14 freezes the company-facing archive after source-hash checks, deterministic packaging and clean-room verification. The final ZIP contains a per-file SHA-256 content manifest plus `VERIFY_SUBMISSION.py`; the external `dist/ais_eta_takehome_submission_final_manifest.json` records the byte-level archive SHA-256. This milestone changes packaging/reproducibility controls only — the M10 model, split and final predictions remain unchanged.

## Claim boundaries

**Supported:** performance under the frozen M10 company-reference protocol; causal historical feature construction; reference-quality diagnostics; frozen-model attribution; and the separate physical-arrival research branch within its documented scope.

**Not established:** observed ATA accuracy from `Tracks.eta`; superiority over the externally developed ETA model; unseen-port generalization; berth/all-fast prediction; or safety-critical navigation.
Historical **reported AIS ETA** updates are not available in `Positions`; only the latest exercise reference in `Tracks` is used.

## Repository structure

```text
src/        reusable data/feature/modelling code
scripts/    milestone pipelines and verification
reports/    frozen benchmark reports and aggregate diagnostics
models/     frozen M10 model artifact
config/     versioned research configuration
docs/       model card, reproducibility and scope documentation
tests/      deterministic contract/unit tests
```

Company raw AIS files are intentionally excluded from the submission archive.
