# Data placement

The company-provided AIS CSV files are intentionally excluded from the clean submission package.

To reproduce the pipeline, place these files in `data/`:

- `vessel_positions_part1.csv`
- `vessel_positions_part2.csv`
- `vessel_tracks.csv`

The project also creates `data/derived/m0c_ship_states.pkl.gz` during M0C. The clean submission excludes both raw and derived company data.
