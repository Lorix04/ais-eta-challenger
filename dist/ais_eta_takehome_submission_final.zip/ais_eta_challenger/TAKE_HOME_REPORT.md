# Take-home report — Company Reference-ETA Benchmark

## 1. Exercise definition

The company clarified that **`Tracks.eta` should be used as the ground-truth/reference value for the technical exercise**. Accordingly, this report treats the latest ETA contained in `Tracks` as the supervised reference target.

This is intentionally called **`reference_eta`**, not observed Actual Time of Arrival (ATA). AIS Message 5 defines ETA as voyage-related estimated information; the company instruction is followed exactly without silently changing the target into a reconstructed physical arrival.

The earlier physical port-entry research (M0–M9) is preserved as a separate secondary branch and is summarized later in this report.

## 2. Dataset formulation

The supplied data contains two relevant roles:

- `Positions`: historical AIS observations over time for each vessel;
- `Tracks`: latest available vessel state, including the exercise ETA reference.

The primary M10 dataset contains **439 parseable ship ETA references across 439 MMSIs**. The modelling unit is one MMSI / Tracks record, not each minute-level historical row.

For vessel `i`, the target is:

`target_tte_h = parsed(Tracks.eta_i) - Tracks.last_update_i`

Historical features are constructed only from `Positions` observations satisfying:

`recorded_at <= Tracks.last_update`

The ETA itself is never a feature.

## 3. Reference-ETA parsing and audit

AIS Message-5 ETA encodes month/day/hour/minute but not a year. The implementation therefore resolves the nearest valid previous/current/next year relative to `Tracks.last_update` using a deterministic rule fixed before final evaluation.

Across the 439 parseable references:

| Reference status | Rows |
|---|---:|
| Past >24 h | 51 |
| Past 1–24 h | 10 |
| Past <1 h | 3 |
| Future 0–7 d | 319 |
| Future 7–14 d | 31 |
| Future 14–30 d | 17 |
| Future >30 d | 8 |

The strict company benchmark deliberately retains all parseable references. No stale-looking, past or far-future values are deleted after looking at performance.

## 4. Features

The candidate feature sets were built from information available at the latest snapshot time.

### Current snapshot

- latitude / longitude;
- SOG / COG / heading;
- draught;
- navigation status;
- vessel type / flag;
- destination string normalized to `destination_norm`;
- message count / feed context;
- hour-of-day and day-of-week encodings.

### Optional causal history

Historical `Positions` was summarized using only observations at or before `Tracks.last_update`, including recent movement and state-history aggregates. The latest matching Position has median age **0.55 min** relative to `Tracks.last_update`; P95 is **174.7 min**.

## 5. Validation protocol

The 439 MMSIs are split using a deterministic SHA-256 hash of MMSI only:

- train: **321**;
- calibration: **65**;
- final test: **53**.

The split is target-free. Candidate models and the selection rule were frozen before opening the final test.

The fixed candidate suite was:

1. global train median;
2. destination-specific train median with global fallback;
3. Ridge using current + causal-history features;
4. CatBoost using current snapshot;
5. CatBoost using current snapshot + causal history.

No broad hyperparameter search or post-final-test tuning was used.

## 6. Calibration model selection

### Strict all-parseable reference task

| Candidate | Calibration MAE |
|---|---:|
| **CatBoost current snapshot** | **339.8 h** |
| destination median + fallback | 343.4 h |
| CatBoost current + history | 346.2 h |
| global train median | 353.4 h |
| Ridge current + history | 448.9 h |

The strict model selected before final opening was **CatBoost current snapshot**.

### Future-reference diagnostic

For a separate diagnostic that excludes references already in the past, the calibration winner was the simple **destination median + global fallback** (191.5 h MAE), ahead of current CatBoost (200.7 h).

This diagnostic did not change the strict primary model.

## 7. Final strict result

The strict benchmark includes every parseable company reference ETA.

On the locked 53-row final test, the frozen current-snapshot CatBoost obtained:

- **MAE: 312.0 h**;
- **median absolute error: 25.3 h**;
- **P90 absolute error: 560.4 h**;
- **43.4% within ±24 h**;
- **60.4% within ±48 h**.

The difference between mean and median is substantial and is investigated explicitly rather than hidden.

## 8. M11 — reference quality and error forensics

M11 performs no training or model selection. It explains the strict benchmark distribution while retaining every label.

Key findings:

- **64/439 (14.6%)** references are already in the past at `last_update`;
- **56/439** are more than 7 days in the future;
- **19/439** have absolute horizon greater than 90 days;
- **86.1%** of ETA values are exactly on `:00` and **93.8%** on `:00` or `:30`;
- five rows have less than 90 days between the chosen and second-best year interpretation;
- seven rows have `01/01 00:00` or `01/01 01:01` placeholder-like patterns, but remain in the strict benchmark;
- on the strict final test, the top 5 errors account for **79.1%** of total absolute error and the top 10 for **91.4%**.

For context, the **same frozen strict CatBoost** has **28.6 h MAE** and **18.1 h median absolute error** on the 40 final references that fall 0–7 days in the future. This is post-hoc diagnostic evidence only; it does not replace the strict benchmark.

The intended interpretation is not “the company target is invalid”. It is that the latest reported/reference ETA has observable quality variation that materially affects aggregate error statistics.

## 9. M12 — frozen model explainability

M12 reloads the exact frozen CatBoost artifact and reproduces all **53/53** final predictions. It does not refit, prune or reselect the model.

The strongest single feature under both CatBoost native importance and calibration mean absolute SHAP is **`destination_norm`**. Current latitude, SOG, navigation status, COG and vessel type are also important.

Grouped SHAP on calibration shows the dominant information families are:

| Feature group | Mean absolute grouped SHAP |
|---|---:|
| motion | 13.41 h |
| voyage state | 12.39 h |
| location | 11.97 h |
| vessel context | 6.32 h |
| time context | 4.21 h |
| feed context | 1.20 h |

A no-retraining masking sensitivity check on calibration also shows the largest prediction shifts when voyage-state/destination, location and motion information are collapsed to train-typical values.

Importantly, the history-heavy CatBoost had already been tested before final opening and did not improve strict calibration: **346.2 h** versus **339.8 h** for current-snapshot CatBoost. On the future-reference diagnostic, history was essentially tied with current CatBoost while the destination median was better.

The supported statement is therefore narrow: **for the supplied latest `Tracks.eta` reference, causal historical Positions summaries did not add stable calibration value beyond the latest-state information already available.** This is not a general claim that vessel history is useless for physical ETA prediction.

## 10. Why extreme references dominate the strict MAE

The frozen CatBoost predicts within a range of roughly **−109.5 h to +93.8 h** on the final set. The supplied strict reference targets span roughly **−3055 h to +3553 h**.

A few examples illustrate the tail:

| Vessel | Reference TTE | Frozen prediction | Absolute error |
|---|---:|---:|---:|
| MIDEA | +3553.3 h | +34.8 h | 3518.4 h |
| DURO | −3055.0 h | +8.2 h | 3063.2 h |
| GIOVANNI E TOMMASO | −2514.9 h | +6.4 h | 2521.2 h |

The model's SHAP contributions remain on the scale of tens of hours; it is not learning a multi-month stale-reference regime. These rows remain in the strict benchmark as supplied.

## 11. Secondary branch — physical port-entry ETA research

Before the company's final reference-target clarification, the project investigated a separate maritime question: time to an AIS-derived physical port-entry event for Catania and Augusta.

That branch includes:

- AIS/provider and sentinel-value forensics;
- semantic motion-state construction;
- Catania/Augusta port-call reconstruction and manual audit;
- train-only historical route retrieval;
- grouped/temporal validation;
- an explicit stop condition that rejected residual ML when it worsened validation;
- reliability, uncertainty and ETA-stability diagnostics.

The retained physical predictor was train-only route-kNN remaining distance divided by robust trailing speed. On its own locked chronological holdout, **route-kNN MAE was 36.5 min versus 37.7 min geodesic**, and the paired bootstrap interval for the gain included zero.

This branch is useful domain analysis and supports alternative use cases, but it is **not** substituted for the company-defined M10 reference benchmark.

## 12. What is supported

- exact implementation of the company instruction to use `Tracks.eta` as reference;
- one supervised sample per MMSI/reference record;
- causal use of `Positions` history;
- calibration-only selection and one-time final evaluation;
- explicit label-quality/error forensics without post-hoc deletion;
- frozen-model attribution and pre-final architecture ablation;
- separate physical-arrival research with its own frozen evaluation.

## 13. What is not established

- `Tracks.eta` as observed ATA;
- superiority over the externally developed ETA model, whose inputs/protocol are unknown;
- unseen-port generalization;
- berth/all-fast prediction;
- safety-critical navigational suitability;
- the secondary research gate is not an **official PBP** (Pilot Boarding Place) or official port boundary;
- a causal interpretation of SHAP/feature importance;
- that history is generally useless for ETA prediction.

## 14. Reproducibility and delivery

The company-facing archive excludes the raw AIS files and high-volume row-level derived data. With the three supplied CSVs placed under `data/`, the project documents the replay sequence in [`docs/REPRODUCIBILITY.md`](docs/REPRODUCIBILITY.md).

The M10 final holdout has already been opened and is protected from accidental rescoring. M11 and M12 are diagnostic-only milestones and preserve the frozen model/split.

M14 performs the **final submission freeze** without retraining or rescoring. The final ZIP is built with sorted inputs and fixed archive metadata, contains a SHA-256 manifest for every payload file, and includes a stdlib-only integrity verifier. The archive is then extracted into a fresh directory where integrity verification, analytical tests and static compilation are rerun. The final ZIP itself is identified by an external SHA-256 manifest.

## 15. Alternative use cases identified

The same foundation can support:

- port-call / turnaround intelligence;
- anchorage and congestion proxies;
- AIS data-quality and stale-state scoring;
- route/behaviour anomaly detection;
- destination resolution and confidence;
- ETA discrepancy/reliability once historical **reported AIS ETA** becomes available at aligned timestamps.

## References

Primary domain/model references are listed in [`REFERENCES.md`](REFERENCES.md).
