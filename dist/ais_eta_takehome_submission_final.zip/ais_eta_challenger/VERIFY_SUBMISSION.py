#!/usr/bin/env python3
"""Stdlib-only integrity verification for the frozen submission payload."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SUBMISSION_CONTENT_MANIFEST.json"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    m = json.loads(MANIFEST.read_text())
    assert m["status"] == "M14_FINAL_SUBMISSION_FROZEN"
    expected = {row["path"]: row for row in m["files"]}
    actual = sorted(
        str(p.relative_to(ROOT)).replace("\\", "/")
        for p in ROOT.rglob("*")
        if p.is_file() and p.name != MANIFEST.name and "__pycache__" not in p.parts and not p.name.endswith((".pyc", ".pyo"))
    )
    assert actual == sorted(expected), "payload file list differs from frozen manifest"
    for rel, row in expected.items():
        p = ROOT / rel
        assert p.stat().st_size == row["size"], rel
        assert sha256(p) == row["sha256"], rel
    model = ROOT / "models" / "m10_strict_reference_catboost.cbm"
    assert sha256(model) == m["frozen_artifacts"]["m10_model_sha256"]
    print(f"PASS final submission content manifest: {len(expected)} files")
    print(f"PASS frozen M10 model SHA-256: {sha256(model)}")
    print("PASS no file is missing, added or modified")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
