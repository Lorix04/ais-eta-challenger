# Model card — Company Reference-ETA Benchmark

## Model identity

**Frozen primary artifact:** `models/m10_strict_reference_catboost.cbm`
**SHA-256:** `efbb86375751e901c48c2f5724514828a10f9eb8ff08ffaabf2d875e369ef86a`

## Intended use

Predict the **company-provided ETA reference stored in `Tracks.eta`** for the technical exercise.

The target is expressed as time from `Tracks.last_update` to the parsed reference ETA. The model is intended for offline evaluation of the supplied exercise dataset, not for safety-critical navigation or deployment as an operational ETA service.

## Target semantics

`Tracks.eta` is treated as the exercise reference because the company explicitly instructed that it may be used as ground truth/reference for this task.

It is **not** relabelled as observed Actual Time of Arrival (ATA). AIS Message 5 defines ETA as voyage-related estimated information.

## Unit of supervision

Exactly one supervised row per MMSI / Tracks record. Historical `Positions` observations may be used to derive causal summaries up to `Tracks.last_update`; they are not treated as thousands of independent copies of the same ETA label.

## Frozen input features

The selected strict CatBoost uses 14 current-snapshot features:

- `track_lat`, `track_lon`;
- `track_sog`, `track_cog`, `track_heading`;
- `track_draught`;
- `ship_type_cat`, `flag_cat`;
- `destination_norm`, `nav_status_cat`;
- `track_msg_count`;
- `last_hour_sin`, `last_hour_cos`, `last_dow`.

No ETA/reference field is an input feature.

## Split and model selection

Deterministic target-free SHA-256 split of MMSI:

- train 321;
- calibration 65;
- final test 53.

Candidate selection was performed on calibration only. The final test was opened once.

Candidate models included global/destination medians, Ridge, CatBoost current snapshot and CatBoost current + causal history.

## Frozen strict final result

Calibration selected **CatBoost current snapshot**.

On 53 final-test MMSIs:

- MAE **312.0 h**;
- median absolute error **25.3 h**;
- P90 absolute error **560.4 h**;
- 43.4% within ±24 h;
- 60.4% within ±48 h.

The benchmark retains every parseable company reference, including past and far-future values.

## Reference-quality context

M11 is diagnostic only and does not change the benchmark:

- 64/439 references are already in the past at snapshot time;
- 56/439 are >7 days in the future;
- top 5 strict final errors account for 79.1% of total absolute error;
- on the same frozen model, the 40 final references 0–7 days in the future have 28.6 h MAE.

That subset result is explanatory only and is not promoted as a replacement final benchmark.

## Explainability

M12 reproduces the frozen artifact exactly and uses CatBoost native importance and SHAP as **model attribution**, not causal evidence.

`destination_norm` is the strongest single feature. The dominant groups are voyage state, current motion and current location.

A history-heavy CatBoost was tested before final opening and did not improve strict calibration over the selected current-snapshot model.

## Limitations

- The target is a latest ETA reference, not observed ATA.
- The externally developed ETA model is unavailable, so superiority/feature parity cannot be evaluated.
- Extreme past/far-future reference values dominate the mean error.
- Message-5 ETA does not encode a year; the benchmark uses a deterministic nearest-year interpretation.
- No unseen-port, berth/all-fast or safety-critical generalization claim is made.
- SHAP/feature importance does not imply maritime causality.

## Secondary model — physical port-entry research

A separate frozen branch predicts AIS-derived physical port-entry events for Catania/Augusta. It is preserved as secondary domain research and must not be presented as the primary company benchmark.

Its locked final result was 36.5 min MAE for route-kNN physics versus 37.7 min geodesic, with the paired gain interval including zero.
