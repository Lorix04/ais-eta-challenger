# External references used in the project

Primary / authoritative sources are preferred for domain semantics.

1. **DCSA Port Call Standard** — standardized operational timestamps and port-call services.  
   https://dcsa.org/standards/port-call

2. **DCSA Port Call 2.0 Use Cases** — explicit ETA/RTA/PTA/ATA semantics for berth and Pilot Boarding Place, plus pilotage/towage/mooring events.  
   https://reference.dcsa.org/content/standards/releases/port-call/v2/pc-v2-use-cases

3. **IMO Just-In-Time Arrival Guide overview** — PBP arrival depends on berth, fairway and nautical-service availability.  
   https://www.imo.org/en/mediacentre/pages/whatsnew-1502.aspx

4. **USCG NAVCEN AIS Class A reports** — official reporting cadence and field/sentinel semantics based on ITU-R M.1371.  
   https://www.navcen.uscg.gov/ais-class-a-reports

5. **Evmides et al. (2024)**, *Enhancing Prediction Accuracy of Vessel Arrival Times Using Machine Learning* — AIS ETA work with route-grouped splitting and external PCS arrival truth.  
   https://www.mdpi.com/2077-1312/12/8/1362

6. **Barber & Pananjady (2026)**, *Predictive inference for time series: why is split conformal effective despite temporal dependence?* — limits/analysis of conformal prediction under temporal dependence.  
   https://proceedings.mlr.press/v313/barber26a.html

7. **AdSP Mare di Sicilia Orientale — Porto di Augusta** — official description of outer/inner roadstead and two entrances.  
   https://www.adspmaresiciliaorientale.it/porto-di-augusta/

8. **AdSP Mare di Sicilia Orientale — Porto di Catania** — official port/berth/fondale information used as domain context.  
   https://www.adspmaresiciliaorientale.it/porto-di-catania/

## M10 target semantics

- **USCG NAVCEN — AIS Class A Ship Static and Voyage Related Data (Message 5)**: ETA is transmitted as `MMDDHHMM UTC` and does not contain a year. https://www.navcen.uscg.gov/ais-class-a-static-voyage-message-5
- **Evmides et al. (2024), Journal of Marine Science and Engineering 12(8):1362**: recent AIS ETA benchmark using multiple ML models and route-aware splitting; useful as methodological context, not directly comparable to the company-reference target used in M10. https://www.mdpi.com/2077-1312/12/8/1362

## M11 reference-quality semantics

- **IMO Resolution A.1106(29)**, *Revised guidelines for the onboard operational use of shipborne AIS*: departure, destination and ETA are manually entered by the OOW at voyage start and when changes occur. https://www.navcen.uscg.gov/sites/default/files/pdf/ais/references/IMO_A1106_29_Revised_guidelines.pdf
- **USCG NAVCEN — AIS Message 5**: ETA is encoded as `MMDDHHMM UTC` without a year. https://www.navcen.uscg.gov/ais-class-a-static-voyage-message-5
- **A Reproducible Workflow for AIS-Based ETA Forecasting (2026)**: recent AIS ETA workflow documenting inconsistent manually entered destination fields and the need for structured preprocessing. https://www.mdpi.com/2571-9394/8/4/70

## M12 frozen-model explainability

- **CatBoost — Feature importances**: official definitions of `PredictionValuesChange`, `LossFunctionChange`, SHAP and interaction importance. https://catboost.ai/docs/en/features/feature-importances-calculation
- **CatBoost — ShapValues**: SHAP contribution semantics and additivity for CatBoost models. https://catboost.ai/docs/en/concepts/shap-values
