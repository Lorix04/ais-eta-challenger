# Executive summary — Company Reference-ETA Benchmark

## Task

The company clarified that, for the exercise, **the ETA contained in `Tracks` should be used as the reference/ground-truth value**. The primary task is therefore to predict that latest reference ETA from the current vessel state and causal historical information in `Positions`.

The project uses one supervised example per MMSI. `Tracks.eta` is target-only; historical features use only `Positions.recorded_at <= Tracks.last_update`.

## Dataset and validation

There are **439 parseable ship ETA references across 439 MMSIs**. The deterministic target-free split is **321 train / 65 calibration / 53 final test**. Candidate models were selected on calibration only, then the final test was opened once.

## Final strict benchmark

Calibration selected **CatBoost on the current/latest Tracks snapshot**.

| Metric | Final test |
|---|---:|
| Rows | 53 |
| MAE | **312.0 h** |
| Median absolute error | **25.3 h** |
| P90 absolute error | 560.4 h |
| Within ±24 h | 43.4% |
| Within ±48 h | 60.4% |

The large mean/median gap is a property of the supplied reference distribution, not hidden by post-hoc filtering.

## Why the mean is so large

M11 keeps all strict labels and explains the heavy tail:

- 64/439 reference ETAs are already in the past at snapshot time;
- 56/439 are more than 7 days in the future;
- the top 5 final-test errors explain **79.1%** of total absolute error;
- the same frozen model has **28.6 h MAE** on the 40 final references 0–7 days in the future.

That 0–7 day number is diagnostic only; the official strict result remains 312.0 h MAE.

## What the frozen model learned

M12 reproduces all 53 final predictions from the frozen CatBoost artifact and uses native importance/SHAP only for explanation. `destination_norm` is the strongest single feature; voyage state, current motion and current location dominate the grouped attribution.

A CatBoost with additional causal history had already been tested before final opening and did **not** improve calibration. For the future-reference diagnostic, a simple train-only destination median was the calibration winner. The evidence therefore does not support “more history / more ML is automatically better” for this particular latest-state reference target.

## Secondary domain work

Before the final target clarification, M0–M9 studied a different question: **physical port-entry ETA** reconstructed from AIS for Catania and Augusta. That branch remains frozen as additional maritime-domain work. It includes provider/data-quality forensics, port-call reconstruction, train-only historical routing, leakage-resistant validation, uncertainty and stability analysis.

It is not used to overwrite or reinterpret the company-defined M10 benchmark.

## Bottom line

The submission provides:

- an exact implementation of the company-defined `Tracks.eta` benchmark;
- a frozen train/calibration/final evaluation protocol;
- explicit diagnosis of reference-label quality rather than silent filtering;
- model explainability without post-final tuning;
- a separate domain-aware physical-arrival investigation showing what changes when the target itself changes;
- an M14 deterministic final submission freeze with per-file SHA-256 integrity verification and clean-room package tests.

No claim is made that the submission beats the externally developed ETA model because its information set and evaluation protocol were not supplied.
Historical **reported AIS ETA** updates are not available in `Positions`; the exercise therefore predicts the latest `Tracks.eta` reference rather than evaluating a longitudinal reported-ETA series.


## Final reproducibility status

M14 is packaging/integrity only. It re-verifies the frozen M10/M6 hashes, builds the final archive deterministically, and validates the extracted package with its content-manifest verifier, analytical tests and static compilation. No model, split or final prediction is changed.

## M16D — Historical Route-Analogue Expert

Post-freeze research branch M16D is complete. On the frozen 386-row development population, a nested OOF DTW route-analogue expert reaches **194.98 h MAE** and **292.90 h P90 AE**, improving on the direct CatBoost current+history-aggregate OOF baseline (208.36 h MAE) and on the M16A raw destination median (202.97 h MAE). The old 53-row M10 final set was not used for selection or scoring. Because the P95 tail remains heavy, the route expert is retained for M16G rather than presented as a replacement for the frozen M14 submission. See `reports/M16D_REPORT.md`.

## M16E — Maritime / Physics Expert

Post-freeze M16E is complete. A leakage-safe physics expert uses catalog-resolved destination coordinates, great-circle remaining distance, causal recent median SOG and an optional local-sinuosity route-detour proxy. It is applicable to **115/386 development rows (29.8%)**. On those eligible rows it reaches **161.48 h MAE, 2.64 h MedAE and 93.33 h P90 AE**, versus **168.39 h, 8.82 h and 108.96 h** for the M16D route analogue; paired absolute error is lower for physics on **69.6%** of eligible rows. A fixed target-free hard gate (physics when eligible, M16D otherwise) reaches **192.93 h pooled OOF MAE**, a **2.06 h** improvement over M16D with **3/5** outer-fold wins. The 53 old-final MMSIs remain hard-blocked. Great-circle distance is explicitly treated as a lower bound/proxy, not a navigational route distance; no water-mask/chart routing dataset is claimed. See `reports/M16E_REPORT.md`.
## M16F — Tabular Challenger Panel

Post-freeze M16F is complete. Five tabular families share the same target-free representation built from current AIS state, causal compact history, M16B canonical-destination metadata and M16E geometry/data-quality features; no M16C/D/E expert prediction and no target-derived `reference_eta_status` is used as a feature. Ten configurations are predeclared and each family is selected only through 3-fold inner CV inside the frozen M16A outer folds. HistGradientBoosting is the best tabular family at **197.28 h pooled OOF MAE, 27.16 h MedAE and 292.84 h P90 AE**, versus **206.14 h** for the frozen M16A current-snapshot CatBoost. It wins **5/5 outer folds** against that baseline. The M16F CatBoost on the same enhanced representation reaches **197.87 h MAE**, so most of the improvement appears to come from representation/robustness rather than a dramatic family-specific advantage. M16D route analogue remains the best pooled single expert at **194.98 h MAE**; M16F HistGradientBoosting nevertheless wins 3/5 folds against it and is retained as the tabular component for M16G. The 53 old-final MMSIs remain hard-blocked. See `reports/M16F_REPORT.md`.

## M16G — Mixture of Experts / OOF Stacking

Post-freeze M16G is complete and passes its development-only stability gate. Four frozen expert families are combined: M16C hierarchical destination prior, M16D route analogue, M16E physics-gate/route fallback and M16F HistGradientBoosting. For every outer fold, expert predictions used to train the meta learner are regenerated as inner-OOF predictions inside that outer-train; no in-sample base prediction and no old-final MMSI is used. The selected nested mixture reaches **185.88 h OOF MAE, 19.34 h MedAE and 290.68 h P90 AE**, versus **192.93 h MAE** for the strongest frozen single operational expert, a **7.04 h gain** with **4/5 fold wins**. Exact ties are common because conservative hard gates often preserve the baseline expert; among rows where M16G actually switches prediction, the switch improves absolute error **54.6%** of the time. This is development-only challenger evidence and does not reopen the M14 submission. See `reports/M16G_REPORT.md`.


## M16H post-freeze challenger uncertainty
The M16G point predictor remains unchanged. A development-only cross-fitted error-risk + residual/conformal-style wrapper reaches 80.05% empirical coverage for a nominal central-80% interval while reducing mean width from 221.26 h (global residual baseline) to 159.42 h. Confidence tiers are useful for typical-error triage (MedAE 3.32 h HIGH, 19.17 h MEDIUM, 84.40 h LOW), but heavy reference-ETA pathologies remain and subgroup coverage is not guaranteed.


## M16I red-team conclusion
The post-freeze M16 challenger survives fair fold, target-magnitude trim, winsorised and destination-removal stresses: M16G remains 7.04 h better in pooled MAE than the best frozen single expert, all five leave-one-fold-out views retain positive gain, and M16H remains at 80.05% pooled coverage. The red-team also finds material heavy-tail sensitivity: the paired-bootstrap 95% interval crosses zero and five rows contribute 51.0% of total positive gain. Therefore M16I freezes `PASS_RED_TEAM_WITH_HEAVY_TAIL_CAVEAT`; no unseen-data superiority claim is made and the M14 submission remains official.

## Post-freeze M16 challenger

A separate leakage-controlled challenger branch was developed after the official M14 freeze. M16 combines destination semantics, route analogues, physics, robust tabular prediction, nested OOF mixture-of-experts and calibrated confidence. The official development-only MoE result is 185.88 h MAE, but M16I red-team analysis retains a heavy-tail caveat because the paired-bootstrap 95% gain interval crosses zero. Therefore M16 is frozen for **new untouched holdout validation only**; it does not replace M14.
