# External references used in the project

Primary / authoritative sources are preferred for domain semantics.

1. **DCSA Port Call Standard** — standardized operational timestamps and port-call services.  
   https://dcsa.org/standards/port-call

2. **DCSA Port Call 2.0 Use Cases** — explicit ETA/RTA/PTA/ATA semantics for berth and Pilot Boarding Place, plus pilotage/towage/mooring events.  
   https://reference.dcsa.org/content/standards/releases/port-call/v2/pc-v2-use-cases

3. **IMO Just-In-Time Arrival Guide overview** — PBP arrival depends on berth, fairway and nautical-service availability.  
   https://www.imo.org/en/mediacentre/pages/whatsnew-1502.aspx

4. **USCG NAVCEN AIS Class A reports** — official reporting cadence and field/sentinel semantics based on ITU-R M.1371.  
   https://www.navcen.uscg.gov/ais-class-a-reports

5. **Evmides et al. (2024)**, *Enhancing Prediction Accuracy of Vessel Arrival Times Using Machine Learning* — AIS ETA work with route-grouped splitting and external PCS arrival truth.  
   https://www.mdpi.com/2077-1312/12/8/1362

6. **Barber & Pananjady (2026)**, *Predictive inference for time series: why is split conformal effective despite temporal dependence?* — limits/analysis of conformal prediction under temporal dependence.  
   https://proceedings.mlr.press/v313/barber26a.html

7. **AdSP Mare di Sicilia Orientale — Porto di Augusta** — official description of outer/inner roadstead and two entrances.  
   https://www.adspmaresiciliaorientale.it/porto-di-augusta/

8. **AdSP Mare di Sicilia Orientale — Porto di Catania** — official port/berth/fondale information used as domain context.  
   https://www.adspmaresiciliaorientale.it/porto-di-catania/

## M10 target semantics

- **USCG NAVCEN — AIS Class A Ship Static and Voyage Related Data (Message 5)**: ETA is transmitted as `MMDDHHMM UTC` and does not contain a year. https://www.navcen.uscg.gov/ais-class-a-static-voyage-message-5
- **Evmides et al. (2024), Journal of Marine Science and Engineering 12(8):1362**: recent AIS ETA benchmark using multiple ML models and route-aware splitting; useful as methodological context, not directly comparable to the company-reference target used in M10. https://www.mdpi.com/2077-1312/12/8/1362

## M11 reference-quality semantics

- **IMO Resolution A.1106(29)**, *Revised guidelines for the onboard operational use of shipborne AIS*: departure, destination and ETA are manually entered by the OOW at voyage start and when changes occur. https://www.navcen.uscg.gov/sites/default/files/pdf/ais/references/IMO_A1106_29_Revised_guidelines.pdf
- **USCG NAVCEN — AIS Message 5**: ETA is encoded as `MMDDHHMM UTC` without a year. https://www.navcen.uscg.gov/ais-class-a-static-voyage-message-5
- **A Reproducible Workflow for AIS-Based ETA Forecasting (2026)**: recent AIS ETA workflow documenting inconsistent manually entered destination fields and the need for structured preprocessing. https://www.mdpi.com/2571-9394/8/4/70

## M12 frozen-model explainability

- **CatBoost — Feature importances**: official definitions of `PredictionValuesChange`, `LossFunctionChange`, SHAP and interaction importance. https://catboost.ai/docs/en/features/feature-importances-calculation
- **CatBoost — ShapValues**: SHAP contribution semantics and additivity for CatBoost models. https://catboost.ai/docs/en/concepts/shap-values

## M16B — AIS destination semantics / UN/LOCODE

- IMO SN/Circ.244, *Guidance on the use of the UN/LOCODE in the Destination Field in AIS Messages* — explains that AIS destination is free text, documents multiple spellings of the same location, and recommends UN/LOCODE: https://www.navcen.uscg.gov/sites/default/files/pdf/NAIS/IMO_SN_Circ244_AIS_UNLOCODE.pdf
- UNECE / UN/CEFACT UN/LOCODE country and vocabulary tables used as provenance for the compact M16B observed-port catalog: https://service.unece.org/trade/locode/ and https://vocabulary.uncefact.org/unlocode
- USCG AIS Encoding Guide — voyage-related ETA/destination encoding guidance and `origin>destination` examples: https://www.navcen.uscg.gov/contact/ais_encoding_guide

## M16C — Fold-safe hierarchical priors / cross-fitting

- scikit-learn, *Target Encoder’s Internal Cross fitting* — shows why category target statistics for training rows must be learned out-of-fold to avoid leakage/overfitting: https://scikit-learn.org/stable/auto_examples/preprocessing/plot_target_encoder_cross_val.html
- scikit-learn, `TargetEncoder` — documents shrinkage toward the global target mean, empirical-Bayes smoothing, and cross-fitting in `fit_transform`: https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.TargetEncoder.html
- Category Encoders, `TargetEncoder` — documents minimum leaf support, smoothing and optional hierarchy for continuous-target encodings: https://contrib.scikit-learn.org/category_encoders/targetencoder.html

## M16D route-analogue references

- Fan, T.; Liu, Q.; Jing, W.; He, Y. (2026). *Incorporation of movement pattern analysis into route searching for ship ETA prediction*. Ocean Engineering 358, 125455. https://doi.org/10.1016/j.oceaneng.2026.125455
- *Development and Application of an Advanced Automatic Identification System (AIS)-Based Ship Trajectory Extraction Framework for Maritime Traffic Analysis* (2024). Journal of Marine Science and Engineering 12(9), 1672. https://www.mdpi.com/2077-1312/12/9/1672

## M16E maritime / physics references

- IMO Resolution MSC.74(69), *Recommendation on Performance Standards for a Universal Shipborne Automatic Identification System (AIS)* — AIS dynamic information includes position, course over ground and speed over ground; destination and ETA are voyage-related data. https://wwwcdn.imo.org/localresources/en/OurWork/Safety/Documents/AIS/Resolution%20MSC.74%2869%29.pdf
- USCG NAVCEN, *AIS Encoding Guide* — voyage ETA/destination encoding guidance, including ETA in UTC and UN/LOCODE destination semantics. https://navcen.uscg.gov/sites/default/files/pdf/AIS/AISGuide.pdf
- Wang, Y.; Zhang, X.; Guo, Y. (2025), *Predicting estimated time of arrival for ships: A frequency-based approach considering met-ocean factors*, Ocean Engineering 337, 121873 — describes indirect ETA modelling as a combination of ship-speed prediction and geographical-distance calculation. https://doi.org/10.1016/j.oceaneng.2025.121873
- Port Digital Twin Development for Decarbonization (2023), Journal of Marine Science and Engineering 11(9), 1777 — describes ETA calculation from current vessel position and remaining route distance, with historical-route estimation. https://www.mdpi.com/2077-1312/11/9/1777

### M16F implementation references
- CatBoost regression objectives and metrics (MAE, Huber, Quantile): https://catboost.ai/docs/en/concepts/loss-functions-regression
- scikit-learn ensemble API (ExtraTrees, RandomForest, HistGradientBoosting): https://scikit-learn.org/stable/api/sklearn.ensemble.html
- scikit-learn SVR API: https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVR.html

### M16G stacking / meta-learning

- scikit-learn, `StackingRegressor`: the final estimator is trained from cross-validated base-estimator predictions. https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.StackingRegressor.html
- scikit-learn example, *Combine predictors using stacking*: out-of-fold base predictions are used to learn a meta-model; simple convex/SuperLearner-like combinations are discussed as an interpretable comparison. https://scikit-learn.org/stable/auto_examples/ensemble/plot_stack_predictors.html


### M16H uncertainty references
- CatBoost documentation, regression objectives including Quantile and MultiQuantile: https://catboost.ai/docs/en/concepts/loss-functions-regression
- Kuchibhotla, A. K. (2020), *Exchangeability, Conformal Prediction, and Rank Tests*, arXiv:2005.06095.
- Barber, R. F., Candès, E. J., Ramdas, A., Tibshirani, R. J. (2022), *Conformal prediction beyond exchangeability*, arXiv:2202.13415.


### M16I red-team / robustness references
- Oliveira, R. I.; Orenstein, P.; Ramos, T.; Romano, J. V. (2024), *Split Conformal Prediction and Non-Exchangeable Data*, JMLR 25(225):1–38 — discusses coverage under non-exchangeability and the limits of classical exchangeability assumptions: https://jmlr.org/papers/v25/23-1553.html
- Barber, R. F.; Candès, E. J.; Ramdas, A.; Tibshirani, R. J. (2022), *Conformal prediction beyond exchangeability* — motivates stress testing under distribution shift/non-exchangeability: https://arxiv.org/abs/2202.13415
- Zhou, Z.; Zhang, X.; Tao, C.; Yang, Y. (2026), *Conformal Prediction Assessment: A Framework for Conditional Coverage Evaluation and Selection* — motivates explicit subgroup/conditional coverage diagnostics rather than relying only on pooled marginal coverage: https://arxiv.org/abs/2603.27189

## M16J validation / reproducibility references

- scikit-learn, `StackingRegressor`: final estimators should be trained on cross-validated base-estimator predictions; using predictions from models fitted on the same rows creates high overfitting risk. https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.StackingRegressor.html
- Reproducible Builds, cryptographic checksums: byte-identical build outputs can be verified with cryptographic hashes. https://reproducible-builds.org/docs/checksums/
- NIST AI RMF / AIRC: test, evaluation, verification and validation (TEVV) should include model validation and assessment, with ongoing evaluation appropriate to deployment context. https://www.nist.gov/itl/ai-risk-management-framework and https://airc.nist.gov/
