# AIS ETA Challenger — Eastern Sicily

Company-facing take-home for the ETA exercise built from the supplied AIS `Positions` and `Tracks` datasets.

## What this submission answers

After clarification from the company, the **primary exercise** is defined as predicting the ETA stored in `Tracks` and using that value as the exercise reference/ground truth.

The project therefore treats:

- `Tracks.eta` as **`reference_eta`** and **target only**;
- `Tracks.last_update` as the prediction-time anchor;
- `Positions` as historical observations used only when `recorded_at <= Tracks.last_update`;
- one MMSI / Tracks record as one supervised example.

`Tracks.eta` is not relabelled as observed Actual Time of Arrival (ATA): the company asked to use it as the exercise reference, and the benchmark follows that instruction exactly.

## Primary result — company reference-ETA benchmark

The reference dataset contains **439 parseable ship ETA references across 439 MMSIs**. A deterministic target-free MMSI split was frozen before the final evaluation:

| Split | Rows |
|---|---:|
| Train | 321 |
| Calibration | 65 |
| Final test | 53 |

Calibration selected **CatBoost using the current/latest Tracks snapshot** for the strict all-parseable benchmark.

| Final-test metric | Result |
|---|---:|
| MAE | **312.0 h** |
| Median absolute error | **25.3 h** |
| P90 absolute error | 560.4 h |
| Within ±24 h | 43.4% |
| Within ±48 h | 60.4% |

The mean is deliberately not "cleaned" after the fact. M11 shows that the error distribution is extremely tail-dominated: the largest 5 final errors explain **79.1%** of total absolute error.

For context only, the **same frozen strict model** has **28.6 h MAE** and **18.1 h median absolute error** on the 40 final references that lie 0–7 days in the future. This is a post-hoc diagnostic, not a replacement benchmark.

## What the model is using

M12 explains the exact frozen CatBoost artifact without refitting it. The strongest single feature is `destination_norm`; current location, SOG/COG/heading and navigation state are also important. The dominant feature groups are voyage state, current motion and current location.

A history-heavy CatBoost was tested **before** the final test and did not improve calibration over the current-snapshot CatBoost. On the future-reference diagnostic, a simple train-only destination median was actually the calibration winner. The project therefore does not claim that a larger model or longer AIS history automatically improves this particular latest-state reference target.

## Reference-label quality findings

The strict benchmark keeps every parseable company reference ETA. Diagnostics show:

- **64/439 (14.6%)** are already in the past at `Tracks.last_update`;
- **56/439** are more than 7 days in the future;
- **86.1%** of ETA minute values are exactly `:00`;
- Message-5 ETA has no year, so year assignment is deterministic but a small number of rows are calendar-sensitive;
- the frozen final predictions span roughly `-109.5 h` to `+93.8 h`, while strict references span roughly `-3055 h` to `+3553 h`.

These properties are reported rather than filtered away.

## Secondary domain-research branch

M0–M9 are preserved as **secondary maritime-domain research**, not as the primary company benchmark. That branch reconstructed physical port-entry events for Catania/Augusta, audited port calls, tested train-only route retrieval, rejected residual ML when it worsened validation, and evaluated uncertainty/stability.

Its final locked physical-arrival holdout produced **36.5 min MAE** for route-kNN physics versus **37.7 min** for geodesic physics; the paired bootstrap interval for the gain included zero. This branch is useful to show how the problem changes when the target is physical arrival rather than the latest reported/reference ETA.

## Recommended reading order

1. [`EXECUTIVE_SUMMARY.md`](EXECUTIVE_SUMMARY.md) — two-minute summary.
2. [`TAKE_HOME_REPORT.md`](TAKE_HOME_REPORT.md) — full company-facing technical narrative.
3. [`reports/M10_REPORT.md`](reports/M10_REPORT.md) — frozen primary benchmark.
4. [`reports/M11_REPORT.md`](reports/M11_REPORT.md) — reference-label/error forensics.
5. [`reports/M12_REPORT.md`](reports/M12_REPORT.md) — frozen-model explainability and ablation.
6. [`docs/MODEL_CARD.md`](docs/MODEL_CARD.md) — intended use, evaluation and limitations.
7. [`reports/M14_REPRODUCIBILITY_REPORT.md`](reports/M14_REPRODUCIBILITY_REPORT.md) — final reproducibility/submission freeze.
8. [`docs/REPRODUCIBILITY.md`](docs/REPRODUCIBILITY.md) — replay and test instructions.

## Final submission freeze

M14 freezes the company-facing archive after source-hash checks, deterministic packaging and clean-room verification. The final ZIP contains a per-file SHA-256 content manifest plus `VERIFY_SUBMISSION.py`; the external `dist/ais_eta_takehome_submission_final_manifest.json` records the byte-level archive SHA-256. This milestone changes packaging/reproducibility controls only — the M10 model, split and final predictions remain unchanged.


## Post-freeze experimental challenger

M16 is a separate experimental branch and does **not** replace the frozen M14 company submission. M16A reconstructs leakage-safe development-only OOF baselines on the former M10 train+calibration population (386 MMSIs) while hard-blocking all 53 already-observed M10 final MMSIs. M16B adds target-free destination canonicalization. M16C then adds nested fold-safe hierarchical destination priors with support thresholds, parent shrinkage and deterministic fallback. M16C reaches **202.56 h pooled OOF MAE** versus **202.97 h** for the raw destination median and **206.14 h** for the reconstructed current-snapshot CatBoost, but wins only 1/5 outer folds versus the raw destination prior, so it is retained as a complementary expert rather than standalone-promoted. A fixed untuned 50/50 complementarity diagnostic reaches **199.86 h MAE**; actual ensemble selection is deferred to M16G. These are development OOF results, not a new untouched final-test score. M16D–M16H are complete; M16I red-team/stress testing is also complete. The only remaining planned submilestone is M16J freeze/company-facing challenger note.

## Claim boundaries

**Supported:** performance under the frozen M10 company-reference protocol; causal historical feature construction; reference-quality diagnostics; frozen-model attribution; and the separate physical-arrival research branch within its documented scope.

**Not established:** observed ATA accuracy from `Tracks.eta`; superiority over the externally developed ETA model; unseen-port generalization; berth/all-fast prediction; or safety-critical navigation.
Historical **reported AIS ETA** updates are not available in `Positions`; only the latest exercise reference in `Tracks` is used.

## Repository structure

```text
src/        reusable data/feature/modelling code
scripts/    milestone pipelines and verification
reports/    frozen benchmark reports and aggregate diagnostics
models/     frozen M10 model artifact
config/     versioned research configuration
docs/       model card, reproducibility and scope documentation
tests/      deterministic contract/unit tests
```

Company raw AIS files are intentionally excluded from the submission archive.

## M16D — Historical Route-Analogue Expert

Post-freeze research branch M16D is complete. On the frozen 386-row development population, a nested OOF DTW route-analogue expert reaches **194.98 h MAE** and **292.90 h P90 AE**, improving on the direct CatBoost current+history-aggregate OOF baseline (208.36 h MAE) and on the M16A raw destination median (202.97 h MAE). The old 53-row M10 final set was not used for selection or scoring. Because the P95 tail remains heavy, the route expert is retained for M16G rather than presented as a replacement for the frozen M14 submission. See `reports/M16D_REPORT.md`.

## M16E — Maritime / Physics Expert

Post-freeze M16E is complete. A leakage-safe physics expert uses catalog-resolved destination coordinates, great-circle remaining distance, causal recent median SOG and an optional local-sinuosity route-detour proxy. It is applicable to **115/386 development rows (29.8%)**. On those eligible rows it reaches **161.48 h MAE, 2.64 h MedAE and 93.33 h P90 AE**, versus **168.39 h, 8.82 h and 108.96 h** for the M16D route analogue; paired absolute error is lower for physics on **69.6%** of eligible rows. A fixed target-free hard gate (physics when eligible, M16D otherwise) reaches **192.93 h pooled OOF MAE**, a **2.06 h** improvement over M16D with **3/5** outer-fold wins. The 53 old-final MMSIs remain hard-blocked. Great-circle distance is explicitly treated as a lower bound/proxy, not a navigational route distance; no water-mask/chart routing dataset is claimed. See `reports/M16E_REPORT.md`.
## M16F — Tabular Challenger Panel

Post-freeze M16F is complete. Five tabular families share the same target-free representation built from current AIS state, causal compact history, M16B canonical-destination metadata and M16E geometry/data-quality features; no M16C/D/E expert prediction and no target-derived `reference_eta_status` is used as a feature. Ten configurations are predeclared and each family is selected only through 3-fold inner CV inside the frozen M16A outer folds. HistGradientBoosting is the best tabular family at **197.28 h pooled OOF MAE, 27.16 h MedAE and 292.84 h P90 AE**, versus **206.14 h** for the frozen M16A current-snapshot CatBoost. It wins **5/5 outer folds** against that baseline. The M16F CatBoost on the same enhanced representation reaches **197.87 h MAE**, so most of the improvement appears to come from representation/robustness rather than a dramatic family-specific advantage. M16D route analogue remains the best pooled single expert at **194.98 h MAE**; M16F HistGradientBoosting nevertheless wins 3/5 folds against it and is retained as the tabular component for M16G. The 53 old-final MMSIs remain hard-blocked. See `reports/M16F_REPORT.md`.

## M16G — Mixture of Experts / OOF Stacking

Post-freeze M16G is complete and passes its development-only stability gate. Four frozen expert families are combined: M16C hierarchical destination prior, M16D route analogue, M16E physics-gate/route fallback and M16F HistGradientBoosting. For every outer fold, expert predictions used to train the meta learner are regenerated as inner-OOF predictions inside that outer-train; no in-sample base prediction and no old-final MMSI is used. The selected nested mixture reaches **185.88 h OOF MAE, 19.34 h MedAE and 290.68 h P90 AE**, versus **192.93 h MAE** for the strongest frozen single operational expert, a **7.04 h gain** with **4/5 fold wins**. Exact ties are common because conservative hard gates often preserve the baseline expert; among rows where M16G actually switches prediction, the switch improves absolute error **54.6%** of the time. This is development-only challenger evidence and does not reopen the M14 submission. See `reports/M16G_REPORT.md`.


### M16H — Probabilistic ETA + Confidence (development-only)
M16H preserves the frozen M16G point estimate as P50 and adds a cross-fitted empirical central-80% interval plus HIGH/MEDIUM/LOW confidence. On the 386 development MMSIs it obtains 80.05% pooled coverage with 159.42 h mean width, 27.9% narrower than a global residual interval. Confidence is relative and target-free at inference time; it is not a conditional coverage guarantee. The 53 old-final MMSIs remain blocked.


## M16I — Red-team, Ablation and Stress Testing

M16I audits the frozen M16G/M16H development-only outputs without re-tuning them. M16G retains **185.88 h MAE** versus **192.93 h** for the strongest frozen single operational expert. Its **7.04 h pooled gain** is positive in 4/5 outer folds, remains positive in all five leave-one-fold-out views, after removing the top 5% of rows by absolute target magnitude (**+9.66 h**), after 95% winsorisation (**+4.07 h**), and after removing the largest net-gain destination (**+2.49 h**). However, a stratified paired bootstrap gives **P(gain>0)=92.18%** with a 95% interval crossing zero (**-2.02 to +20.16 h**) and the top five positive-gain rows account for **51.0%** of total positive gain. The frozen decision is therefore `PASS_RED_TEAM_WITH_HEAVY_TAIL_CAVEAT`: M16 is a promising development challenger, not a proven replacement until scored on a new untouched holdout. See `reports/M16I_REPORT.md`.

## M16 smart challenger — frozen development branch

M16A–J is now closed as a separate post-submission challenger. The frozen nested-OOF Mixture of Experts reaches 185.88 h MAE on the 386-row development population versus 192.93 h for the best single operational expert and 202.97 h for the original destination-median development baseline. The 53 already-observed M10 final MMSIs were not used for M16 selection. M16 is **not** the official submission and is not claimed to be proven superior on unseen data: M14 remains the official immutable package, while M16 is frozen for evaluation on a new untouched company holdout. See `reports/M16_REPORT.md` and `docs/M16_COMPANY_NOTE_IT.md`.
